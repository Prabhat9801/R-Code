matrix(data=c(-3,2,893,0.17))
dim(matrix(data=c(-3,2,893,0.17),nrow=4,ncol=1))

